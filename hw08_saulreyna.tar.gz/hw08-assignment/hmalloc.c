
#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>

#include "hmalloc.h"

// initialize our global free list
free_block static *head = NULL;
free_block static *current = NULL;

const size_t PAGE_SIZE = 4096;
static hm_stats stats; // This initializes the stats to 0.


// associated methods for free list (wouldn't want to make these
// public, so we don't put them in the header file)
void add_block(void* xs, size_t size);
long free_list_length();
free_block* retrieve_free_block(size_t);
void coalesce(free_block* previous, free_block* current, free_block* next);


long free_list_length()
{
    long length = 0;
    free_block *current;

    for (current = head; current != NULL; current = current->next)
    {
        length++;
    }

    return length;
}

void add_block(void *xs, size_t size)
{
    free_block *new_cell = (free_block *)xs;
    new_cell->size = size;

    free_block *current = head;
    free_block *previous = NULL;

    // list is empty, so we simply add the block 
    if (head == NULL)
    {
        new_cell->next = head;
        head = new_cell;
    }
    else
    {
        // look until we've reached a block where
        // we are the larger address
        while ((void *)new_cell > (void *)current)
        {
            previous = current;
            current = current->next;
        }

        // we've finally found a spot, so we know
        // the current cell is our created one, the next cell
        // is the one that got us out of the while loop, and 
        // previous is the cell behind us (if there was one)
        free_block* next = current;
        current = new_cell;

        coalesce(previous, current, next);
    }
}

void coalesce(free_block *previous, free_block *current, free_block *next)
{
    // if there was a cell behind us, then we want to check if previous and
    // current are adjacent
    if (previous != NULL)
    {
        // if they are, then we add to the size of the earlier address
        // and indicate that our current cell is this earlier address
        if (((void*)(previous)) + previous->size == (void*)(current))
        {
            previous->size += current->size;
            current = previous;
        }
        // otherwise, we insert our current cell in between 
        // the previous and next cells
        else
        {
            previous->next = current;
            current->next = next;
        }
    }

    // we have another case where the current cell is adjacent with 
    // the next cell (this also includes the case where we the coalesced
    // previous and current blocks become adjacent with next)
    if (next != NULL) {
        // if current is adjacent with next, then we add to the current 
        // cell size and move the next available address from next 
        // and give it to the current cell
        if (((void*)(current)) + current->size == (void*)(next))
        {
            current->size += next->size;
            current->next = next->next;
        }

        // otherwise, there is a used block in between current and
        // next so we just link the next block as the next available
        // address from current
        else {
            current->next = next;

            // since the check on previous implicitly proved
            // that we are not at the beginning of the list, we 
            // have to check here so that we can assign the 
            // correct head of the free list
            if (previous == NULL)
            {
                head = current;
            }
        }

    }
}

free_block *retrieve_free_block(size_t size)
{

    //start from the first link
    free_block *current = head;
    free_block *previous = NULL;

    // if list is empty, then no free block obv
    if (head == NULL)
    {
        return NULL;
    }

    // look for a free_blocks whose size field
    // is greater than or equal to our requested size
    while (current->size < size)
    {

        // we've reached the end, so we can
        // safely say there is no block here, no, no
        if (current->next == NULL)
        {
            return NULL;
        }
        else
        {
            // moving where we are looking in the list
            previous = current;
            current = current->next;
        }
    }

    // we are out of the while loop, so we've
    // found a block where the size is no longer 
    // greater than a block's size
    if (current == head)
    {
        head = head->next;
    }
    else
    {
        previous->next = current->next;
    }

    // we want to remove the free block from the list and
    // will mostly likely add it back into the list
    return current;
}

hm_stats *
hgetstats()
{
    stats.free_length = free_list_length();
    return &stats;
}

void hprintstats()
{
    stats.free_length = free_list_length();
    fprintf(stderr, "\n== husky malloc stats ==\n");
    fprintf(stderr, "Mapped:   %ld\n", stats.pages_mapped);
    fprintf(stderr, "Unmapped: %ld\n", stats.pages_unmapped);
    fprintf(stderr, "Allocs:   %ld\n", stats.chunks_allocated);
    fprintf(stderr, "Frees:    %ld\n", stats.chunks_freed);
    fprintf(stderr, "Freelen:  %ld\n", stats.free_length);
}

static size_t
div_up(size_t xx, size_t yy)
{
    // This is useful to calculate # of pages
    // for large allocations.
    size_t zz = xx / yy;

    if (zz * yy == xx)
    {
        return zz;
    }
    else
    {
        return zz + 1;
    }
}

void *
hmalloc(size_t size)
{
    stats.chunks_allocated += 1;
    size += sizeof(size_t);

    if (size > PAGE_SIZE)
    {
        int pages = div_up(size, PAGE_SIZE);
        void *mapped = mmap(0, pages * PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        size_t *mapped_size = (size_t *)mapped;
        *mapped_size = pages * PAGE_SIZE; // write the first 8 bytes to the size of the allocation
        
        stats.pages_mapped += pages;
        return (void *)mapped + sizeof(size_t); 
    }
    else
    {
        // we have removed the free block from the free list
        free_block *found_block = retrieve_free_block(size);
        
        if (found_block)
        {
            // we add the leftover space back into the list
            if (found_block->size - size >= 16) {
                add_block((void*)found_block + size, found_block->size - size);
                
            }
            size_t* mapped_size = (size_t*)found_block;
            *mapped_size = size;

            return (void*)found_block + sizeof(size_t);
        }
        else
        {
            void *new_page = mmap(0, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
            stats.pages_mapped += 1;

            // similar to the previous case, we add back the leftover space from the
            // newly created page back into the list
            if (PAGE_SIZE - size >= 16) {
                add_block((void*)new_page + size, PAGE_SIZE - size);
            }
            
            size_t *mapped_size = (size_t *)new_page;
            *mapped_size = size;

            return (void *)new_page + sizeof(size_t);
        }
    }
}

void hfree(void *item)
{
    stats.chunks_freed += 1;

    size_t allocated_space = *(size_t *)(item - sizeof(size_t));
    // printf("allocated_space -> %ld\n", allocated_space);
    if (allocated_space % PAGE_SIZE == 0)
    {

        stats.pages_unmapped += (allocated_space / PAGE_SIZE);
        munmap(item - sizeof(size_t), allocated_space);
    }
    else
    {
        add_block((void *)(item - sizeof(size_t)), allocated_space);
    }
}
